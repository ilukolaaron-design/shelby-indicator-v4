package com.shelby.indicator

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

private val Navy = Color(0xFF101827)
private val Panel = Color(0xFF1B2940)
private val Cyan = Color(0xFF5BCBFF)
private val Green = Color(0xFF42D6A0)
private val Red = Color(0xFFFF7777)
private val Amber = Color(0xFFFFC66D)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ShelbyApp() }
    }
}

@Composable
fun ShelbyApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    val csvFiles = remember { mutableStateListOf<Uri>() }
    val imageFiles = remember { mutableStateListOf<Uri>() }
    var pair by remember { mutableStateOf("EUR/USD") }
    var timeframes by remember { mutableStateOf("1=H4, 2=H1, 3=M15") }
    var endpoint by remember { mutableStateOf("http://10.0.2.2:8000") }
    var result by remember { mutableStateOf<JSONObject?>(null) }
    var imageResult by remember { mutableStateOf<JSONObject?>(null) }
    var status by remember { mutableStateOf("Choose historical OHLC CSV files.") }
    var loading by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.GetMultipleContents()
    ) { uris ->
        csvFiles.clear()
        csvFiles.addAll(uris.take(6))
        result = null
        status = "${csvFiles.size} CSV file(s) selected."
    }
    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        val report = result
        if (uri != null && report != null) {
            try {
                context.contentResolver.openOutputStream(uri)?.use {
                    it.write(report.toString(2).toByteArray(Charsets.UTF_8))
                }
                status = "V4 JSON report saved."
            } catch (e: Exception) {
                status = "Could not save report: ${e.message ?: "storage error"}"
            }
        }
    }

    val imagePicker = rememberLauncherForActivityResult(
        ActivityResultContracts.GetMultipleContents()
    ) { uris ->
        imageFiles.clear()
        imageFiles.addAll(uris.take(6))
        imageResult = null
        status = "${imageFiles.size} chart image(s) selected."
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Navy, surface = Panel)) {
        Scaffold(containerColor = Navy) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(13.dp)
            ) {
                item {
                    Text("SHELBY INDICATOR", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black)
                    Text("VERSION 4.0 • MARKET STRUCTURE DASHBOARD", color = Cyan, fontSize = 11.sp)
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("01  DATA SETUP", color = Cyan, fontWeight = FontWeight.Bold)
                            OutlinedTextField(pair, { pair = it }, Modifier.fillMaxWidth(),
                                label = { Text("Currency pair label") }, singleLine = true)
                            OutlinedTextField(timeframes, { timeframes = it }, Modifier.fillMaxWidth(),
                                label = { Text("CSV order and timeframes") },
                                supportingText = { Text("Example: 1=H4, 2=H1, 3=M15") })
                            OutlinedTextField(endpoint, { endpoint = it }, Modifier.fillMaxWidth(),
                                label = { Text("Backend base URL") },
                                supportingText = { Text("Emulator default: http://10.0.2.2:8000") },
                                singleLine = true)
                        }
                    }
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("02  NUMERICAL OHLC ANALYSIS", color = Cyan, fontWeight = FontWeight.Bold)
                            Text("Upload 2–6 CSV files containing historical Open, High, Low and Close candles.",
                                color = Color.LightGray, fontSize = 12.sp)
                            Button(onClick = { picker.launch("text/*") }, modifier = Modifier.fillMaxWidth()) {
                                Text("SELECT OHLC CSV FILES")
                            }
                            Text("${csvFiles.size} file(s) selected", color = Color.White)
                            Button(
                                onClick = {
                                    if (csvFiles.size < 2) status = "Select at least two CSV files."
                                    else {
                                        loading = true
                                        status = "Calculating indicators and historical follow-through…"
                                        scope.launch {
                                            try {
                                                result = withContext(Dispatchers.IO) {
                                                    ShelbyApi.analyze(context, csvFiles.toList(), pair,
                                                        timeframes, endpoint.trimEnd('/') + "/analyze-csv")
                                                }
                                                status = "Numerical study complete."
                                            } catch (e: Exception) {
                                                status = "Analysis failed: ${e.message ?: "Check backend."}"
                                            } finally { loading = false }
                                        }
                                    }
                                },
                                enabled = !loading, modifier = Modifier.fillMaxWidth()
                            ) {
                                if (loading) CircularProgressIndicator(Modifier.size(18.dp), color = Color.White)
                                else Text("RUN NUMERICAL STUDY")
                            }
                        }
                    }
                }
                item {
                    result?.let { report ->
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            ResultsCard(report)
                            OutlinedButton(
                                onClick = { exportLauncher.launch("shelby_v4_report.json") },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("EXPORT ANALYSIS REPORT (JSON)") }
                        }
                    }
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("03  AI SCREENSHOT REVIEW", color = Cyan, fontWeight = FontWeight.Bold)
                            Text("Optional visual review of 2–6 chart screenshots. Use CSV mode for exact numerical indicator calculations.",
                                color = Color.LightGray, fontSize = 12.sp)
                            OutlinedButton(onClick = { imagePicker.launch("image/*") },
                                modifier = Modifier.fillMaxWidth()) {
                                Text("SELECT CHART SCREENSHOTS")
                            }
                            Text("${imageFiles.size} image(s) selected", color = Color.White, fontSize = 12.sp)
                            OutlinedButton(
                                onClick = {
                                    if (imageFiles.size < 2) status = "Select at least two chart images."
                                    else {
                                        loading = true
                                        status = "Reviewing chart screenshots…"
                                        scope.launch {
                                            try {
                                                imageResult = withContext(Dispatchers.IO) {
                                                    ShelbyApi.analyze(context, imageFiles.toList(), pair,
                                                        timeframes, endpoint.trimEnd('/') + "/analyze-images")
                                                }
                                                status = "Screenshot review complete."
                                            } catch (e: Exception) {
                                                status = "Image review failed: ${e.message ?: "Check backend and AI key."}"
                                            } finally { loading = false }
                                        }
                                    }
                                },
                                enabled = !loading,
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("RUN AI IMAGE REVIEW") }
                        }
                    }
                }
                item { imageResult?.let { ImageResultsCard(it) } }
                item {
                    Text(status, color = Color.LightGray, fontSize = 12.sp)
                    Text(
                        "EDUCATIONAL / HISTORICAL STUDY ONLY. No broker connection or live orders. " +
                        "Scores are not probabilities. Historical behaviour does not predict future results.",
                        color = Amber, fontSize = 11.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun ImageResultsCard(data: JSONObject) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text("AI IMAGE REVIEW", color = Cyan, fontWeight = FontWeight.Bold)
            Text(data.optString("directional_tilt", "NEUTRAL"), color = Color.White,
                fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(data.optString("overview", ""), color = Color.LightGray)
            Text(data.optString("timeframe_findings", ""), color = Color.LightGray, fontSize = 12.sp)
            Text(data.optString("uncertainties", ""), color = Amber, fontSize = 11.sp)
        }
    }
}

@Composable
private fun ResultsCard(data: JSONObject) {
    val score = data.optInt("combined_bullish_score", 50).coerceIn(0, 100)
    val tilt = data.optString("combined_tilt", "NEUTRAL")
    val tint = when (tilt) { "BULLISH" -> Green; "BEARISH" -> Red; else -> Amber }
    val frames = data.optJSONArray("timeframes")
    val validation = data.optJSONObject("historical_validation")
    Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("SHELBY V4 ANALYSIS DASHBOARD", color = Cyan, fontWeight = FontWeight.Bold)
            Text("NUMERICAL RESULTS", color = Cyan, fontWeight = FontWeight.Bold)
            Text(tilt, color = tint, fontSize = 24.sp, fontWeight = FontWeight.Black)
            Text("Bullish evidence agreement: $score / 100", color = Color.White)
            LinearProgressIndicator(progress = { score / 100f },
                modifier = Modifier.fillMaxWidth(), color = Green, trackColor = Red)
            Text(data.optString("overview", ""), color = Color.White)
            val consensus = data.optJSONObject("timeframe_consensus")
            if (consensus != null) {
                Text("TIMEFRAME AGREEMENT", color = Cyan, fontWeight = FontWeight.Bold)
                Text("Bullish ${consensus.optInt("bullish")} • Bearish ${consensus.optInt("bearish")} • " +
                    "Neutral ${consensus.optInt("neutral")}", color = Color.White)
                Text("Largest same-label group: ${consensus.optString("agreement_percent")}%",
                    color = Color.LightGray, fontSize = 12.sp)
                val mixed = consensus.optJSONArray("mixed_timeframes")
                if (mixed != null && mixed.length() > 0) {
                    Text("Timeframes differing from the overall label:", color = Amber, fontSize = 12.sp)
                    for (i in 0 until mixed.length()) Text("• ${mixed.optString(i)}", color = Color.LightGray, fontSize = 11.sp)
                }
            }
            Text("INDICATORS BY TIMEFRAME", color = Cyan, fontWeight = FontWeight.Bold)
            if (frames != null) for (i in 0 until frames.length()) {
                val f = frames.optJSONObject(i) ?: continue
                Text("${f.optString("timeframe")} • ${f.optString("tilt")} • ${f.optInt("bullish_score")}/100",
                    color = Color.White, fontWeight = FontWeight.SemiBold)
                Text("Close ${f.optString("last_close")} | RSI ${f.optString("rsi14")} | " +
                    "MACD hist ${f.optString("macd_histogram")}", color = Color.LightGray, fontSize = 11.sp)
                Text("EMA20 ${f.optString("ema20")} | EMA50 ${f.optString("ema50")} | " +
                    "EMA200 ${f.optString("ema200")}", color = Color.LightGray, fontSize = 11.sp)
                Text("Patterns: ${f.optString("patterns")}", color = Color.LightGray, fontSize = 11.sp)
                Text("Trend: ${f.optString("trend_regime")} • Volatility: ${f.optString("volatility_regime")}",
                    color = Color.LightGray, fontSize = 11.sp)
                Text("ADX ${f.optString("adx14")} • ATR ${f.optString("atr_percent")}% • " +
                    "BB width ${f.optString("bollinger_width_percent")} %", color = Color.LightGray, fontSize = 11.sp)
                val market = f.optJSONObject("market_structure")
                if (market != null) {
                    Text("Swing structure: ${market.optString("label")}", color = Color.White, fontSize = 12.sp)
                    Text("Nearest pivot support ${market.optString("nearest_pivot_support")} • " +
                        "resistance ${market.optString("nearest_pivot_resistance")}", color = Color.LightGray, fontSize = 11.sp)
                }
                Text("Structure: ${f.optString("structure")} • Support zone ${f.optString("support_zone_low")} • " +
                    "Resistance zone ${f.optString("resistance_zone_high")}", color = Color.LightGray, fontSize = 11.sp)
            }
            Text("HISTORICAL FOLLOW-THROUGH STUDY", color = Cyan, fontWeight = FontWeight.Bold)
            if (validation != null) {
                Text("Observations: ${validation.optInt("observations")}", color = Color.White)
                Text("5-candle follow-through: ${validation.optString("hit_rate")}", color = Color.White)
                Text(validation.optString("method"), color = Color.LightGray, fontSize = 11.sp)
            }
            Text(data.optString("limitations", ""), color = Amber, fontSize = 11.sp)
        }
    }
}

private object ShelbyApi {
    private val client = OkHttpClient.Builder().callTimeout(120, TimeUnit.SECONDS).build()

    fun analyze(context: android.content.Context, uris: List<Uri>, pair: String,
                timeframes: String, endpoint: String): JSONObject {
        val builder = MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("pair_label", pair)
            .addFormDataPart("timeframes", timeframes)
        uris.forEachIndexed { index, uri ->
            val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                ?: error("Cannot read CSV ${index + 1}")
            require(bytes.size <= 15 * 1024 * 1024) { "CSV ${index + 1} exceeds 15 MB." }
            val file = File.createTempFile("shelby_$index", ".csv", context.cacheDir)
            file.writeBytes(bytes)
            val mime = context.contentResolver.getType(uri) ?: "application/octet-stream"
            val ext = if (mime.startsWith("image/")) ".jpg" else ".csv"
            builder.addFormDataPart("files", "upload_${index + 1}$ext",
                file.asRequestBody(mime.toMediaType()))
        }
        val request = Request.Builder().url(endpoint).post(builder.build()).build()
        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) error("Server ${response.code}: $body")
            JSONObject(body)
        }
    }
}
