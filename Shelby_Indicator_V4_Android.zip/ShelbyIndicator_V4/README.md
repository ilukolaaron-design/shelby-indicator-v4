# SHELBY INDICATOR 4.0 — Android source project

V4 upgrades the V3 educational chart-study app with a market-structure dashboard and JSON report export. It remains a historical-analysis tool: it does not connect to a broker, stream live prices, place orders, or tell users to enter or exit trades.

## What's new in V4
- Confirmed fractal swing highs and lows (two candles on either side) with a simple higher-high/higher-low, lower-high/lower-low, or mixed structure label.
- Nearest confirmed pivot support/resistance references, alongside the existing recent 30-candle range.
- ADX-based descriptive trend-strength labels and ATR-relative volatility regime labels.
- Bollinger Band width and ATR percentage displayed for each timeframe.
- Timeframe-agreement summary showing bullish, bearish and neutral counts plus timeframes that differ from the combined label.
- Export of the numerical analysis response as a JSON report using Android's save-file picker.

## Retained analysis
- Upload 2–6 historical OHLC CSV files (one file per timeframe).
- EMA 20/50/200, RSI 14, MACD 12/26/9, Bollinger Bands and ATR 14.
- Basic latest-candle pattern descriptions.
- Multi-timeframe evidence score and a historical five-candle follow-through diagnostic.
- Optional AI screenshot review, requiring `OPENAI_API_KEY` on the backend.

## CSV format
Each file needs at least 60 valid rows and these columns:

```csv
timestamp,open,high,low,close,volume
2025-01-01 00:00:00,1.04000,1.04120,1.03950,1.04080,120
2025-01-01 01:00:00,1.04080,1.04200,1.04010,1.04150,145
```

Required columns: `open`, `high`, `low`, `close`. Timestamp and volume are optional. `date`, `datetime`, `time`, `tick_volume`, and `real_volume` aliases are supported. Upload files in the same order as the timeframe mapping, e.g. `1=H4, 2=H1, 3=M15`. Keep the same currency pair and consistent candle source across the files.

A synthetic CSV generator is included under `server/sample_data/`. Its output is artificial and only intended to test that the software runs.

## Start the backend
Python 3.10+ recommended. From the `server` directory:

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8000
```

Health endpoint: `http://127.0.0.1:8000/health`

Numerical CSV analysis does not need an AI API key. Optional screenshot review requires a server-side key:

```bash
# macOS/Linux
export OPENAI_API_KEY="YOUR_KEY"
# Windows PowerShell
$env:OPENAI_API_KEY="YOUR_KEY"
```

Never put the API key in the Android app or commit it to source control.

## Build Android
1. Open this project folder in Android Studio.
2. Install Android SDK 35 and JDK 17 if prompted.
3. Wait for Gradle sync.
4. Run the `app` configuration on an emulator.
5. The default backend URL `http://10.0.2.2:8000` is for an emulator connecting to a backend running on the same computer.

For a physical Android phone, enter the computer's local Wi-Fi IP in the app, for example `http://192.168.1.20:8000`; both devices must be on the same trusted Wi-Fi. This development project uses HTTP for local testing only. Do not expose the backend publicly. A production service needs HTTPS, authentication, request limits, privacy controls and secure secret handling.

## Important interpretation notes
- The combined score is an indicator-agreement index, NOT a probability, prediction, win rate, or guarantee.
- Timeframe agreement counts describe how similar the uploaded timeframe labels are; disagreement is not a forecast.
- Swing highs/lows are confirmed only after later candles appear, so they are delayed descriptions and may not mark final market turning points.
- ADX describes trend strength, not direction. ATR and Bollinger width describe historical volatility, not future volatility.
- The historical follow-through percentage is descriptive, not a trading-system backtest. It excludes spreads, slippage, fees and market impact and may be misleading on small or selected datasets.
- CSV pair/timeframe labels are user supplied and not verified. Indicator calculations depend on clean, correctly ordered OHLC candles.
- Educational software only. Historical patterns do not predict future results. Do not use this app as a basis for real-money trading.
