from io import BytesIO
import numpy as np
import pandas as pd

REQUIRED = {"open", "high", "low", "close"}
ALIASES = {
    "date": "timestamp", "datetime": "timestamp", "time": "timestamp",
    "tick_volume": "volume", "real_volume": "volume"
}

def load_ohlc(raw: bytes) -> pd.DataFrame:
    try:
        df = pd.read_csv(BytesIO(raw))
    except Exception as exc:
        raise ValueError(f"Could not read CSV: {exc}")
    df.columns = [str(c).strip().lower().replace(" ", "_") for c in df.columns]
    df = df.rename(columns=ALIASES)
    missing = REQUIRED - set(df.columns)
    if missing:
        raise ValueError("Missing required columns: " + ", ".join(sorted(missing)))
    for col in ["open", "high", "low", "close", "volume"]:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")
    df = df.dropna(subset=["open", "high", "low", "close"]).copy()
    if "timestamp" in df.columns:
        df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce", utc=True)
        df = df.dropna(subset=["timestamp"]).sort_values("timestamp")
    if len(df) < 60:
        raise ValueError(f"Need at least 60 valid candles; found {len(df)}.")
    invalid = (
        (df.high < df.low) | (df.high < df.open) | (df.high < df.close) |
        (df.low > df.open) | (df.low > df.close)
    )
    if invalid.any():
        raise ValueError("OHLC values are inconsistent in one or more candles.")
    return df.reset_index(drop=True)

def add_indicators(df: pd.DataFrame) -> pd.DataFrame:
    x = df.copy()
    c, h, l = x.close, x.high, x.low
    x["ema20"] = c.ewm(span=20, adjust=False).mean()
    x["ema50"] = c.ewm(span=50, adjust=False).mean()
    x["ema200"] = c.ewm(span=200, adjust=False).mean()

    change = c.diff()
    gain = change.clip(lower=0)
    loss = -change.clip(upper=0)
    avg_gain = gain.ewm(alpha=1/14, adjust=False, min_periods=14).mean()
    avg_loss = loss.ewm(alpha=1/14, adjust=False, min_periods=14).mean()
    rs = avg_gain / avg_loss.replace(0, np.nan)
    x["rsi14"] = 100 - (100 / (1 + rs))
    x.loc[(avg_loss == 0) & (avg_gain > 0), "rsi14"] = 100
    x.loc[(avg_loss == 0) & (avg_gain == 0), "rsi14"] = 50

    fast = c.ewm(span=12, adjust=False).mean()
    slow = c.ewm(span=26, adjust=False).mean()
    x["macd"] = fast - slow
    x["macd_signal"] = x.macd.ewm(span=9, adjust=False).mean()
    x["macd_histogram"] = x.macd - x.macd_signal

    x["bb_mid"] = c.rolling(20).mean()
    sd = c.rolling(20).std(ddof=0)
    x["bb_upper"] = x.bb_mid + 2 * sd
    x["bb_lower"] = x.bb_mid - 2 * sd

    prev = c.shift(1)
    tr = pd.concat([h-l, (h-prev).abs(), (l-prev).abs()], axis=1).max(axis=1)
    x["atr14"] = tr.ewm(alpha=1/14, adjust=False, min_periods=14).mean()

    # Wilder-style ADX, used only as a descriptive trend-strength gauge.
    up_move = h.diff()
    down_move = -l.diff()
    plus_dm = pd.Series(np.where((up_move > down_move) & (up_move > 0), up_move, 0.0), index=x.index)
    minus_dm = pd.Series(np.where((down_move > up_move) & (down_move > 0), down_move, 0.0), index=x.index)
    atr_safe = x["atr14"].replace(0, np.nan)
    plus_di = 100 * plus_dm.ewm(alpha=1/14, adjust=False, min_periods=14).mean() / atr_safe
    minus_di = 100 * minus_dm.ewm(alpha=1/14, adjust=False, min_periods=14).mean() / atr_safe
    dx = 100 * (plus_di - minus_di).abs() / (plus_di + minus_di).replace(0, np.nan)
    x["plus_di"] = plus_di
    x["minus_di"] = minus_di
    x["adx14"] = dx.ewm(alpha=1/14, adjust=False, min_periods=14).mean()
    x["atr_pct"] = 100 * x["atr14"] / c.replace(0, np.nan)
    x["bb_width_pct"] = 100 * (x["bb_upper"] - x["bb_lower"]) / x["bb_mid"].replace(0, np.nan)
    return x

def find_patterns(x: pd.DataFrame) -> list[str]:
    a, b = x.iloc[-1], x.iloc[-2]
    body = abs(float(a.close-a.open))
    rng = max(float(a.high-a.low), 1e-12)
    upper = float(a.high-max(a.open,a.close))
    lower = float(min(a.open,a.close)-a.low)
    found = []
    if body/rng <= 0.10:
        found.append("Doji-like candle")
    if lower >= 2*body and upper <= max(body, rng*0.10) and a.close > a.open:
        found.append("Bullish hammer-like candle")
    if upper >= 2*body and lower <= max(body, rng*0.10) and a.close < a.open:
        found.append("Bearish shooting-star-like candle")
    if b.close < b.open and a.close > a.open and a.open <= b.close and a.close >= b.open:
        found.append("Bullish engulfing-like pattern")
    if b.close > b.open and a.close < a.open and a.open >= b.close and a.close <= b.open:
        found.append("Bearish engulfing-like pattern")
    return found or ["No clear basic pattern in latest candle"]

def market_structure(x: pd.DataFrame, lookback: int = 2) -> dict:
    """Simple confirmed fractal swings; latest two pivots define descriptive structure."""
    highs, lows = [], []
    h = x.high.to_numpy(dtype=float)
    l = x.low.to_numpy(dtype=float)
    for i in range(lookback, len(x) - lookback):
        if h[i] >= max(h[i-lookback:i+lookback+1]) and np.count_nonzero(h[i] == h[i-lookback:i+lookback+1]) == 1:
            highs.append((i, float(h[i])))
        if l[i] <= min(l[i-lookback:i+lookback+1]) and np.count_nonzero(l[i] == l[i-lookback:i+lookback+1]) == 1:
            lows.append((i, float(l[i])))
    high_vals = [v for _, v in highs[-2:]]
    low_vals = [v for _, v in lows[-2:]]
    if len(high_vals) == 2 and len(low_vals) == 2:
        if high_vals[-1] > high_vals[-2] and low_vals[-1] > low_vals[-2]:
            label = "Higher highs + higher lows"
        elif high_vals[-1] < high_vals[-2] and low_vals[-1] < low_vals[-2]:
            label = "Lower highs + lower lows"
        else:
            label = "Mixed / transitioning swings"
    else:
        label = "Not enough confirmed swing points"
    close = float(x.close.iloc[-1])
    prior_highs = [v for _, v in highs if v >= close]
    prior_lows = [v for _, v in lows if v <= close]
    return {
        "label": label,
        "confirmed_swing_highs": len(highs),
        "confirmed_swing_lows": len(lows),
        "latest_swing_high": round(high_vals[-1], 6) if high_vals else "not available",
        "latest_swing_low": round(low_vals[-1], 6) if low_vals else "not available",
        "nearest_pivot_resistance": round(min(prior_highs), 6) if prior_highs else "not available",
        "nearest_pivot_support": round(max(prior_lows), 6) if prior_lows else "not available"
    }


def describe_regime(last: pd.Series, x: pd.DataFrame) -> tuple[str, str]:
    adx = last.adx14
    if pd.isna(adx):
        trend = "insufficient ADX history"
    elif adx >= 25:
        trend = "stronger directional trend"
    elif adx < 18:
        trend = "weaker / ranging conditions"
    else:
        trend = "transitional trend strength"
    recent = x.atr_pct.tail(100).dropna()
    if pd.isna(last.atr_pct) or len(recent) < 10:
        volatility = "insufficient volatility history"
    else:
        baseline = float(recent.median())
        ratio = float(last.atr_pct) / baseline if baseline else 1.0
        volatility = "elevated volatility" if ratio >= 1.35 else "quiet volatility" if ratio <= 0.75 else "typical volatility"
    return trend, volatility


def analyse_frame(df: pd.DataFrame, timeframe: str, filename: str) -> dict:
    x = add_indicators(df)
    last = x.iloc[-1]
    votes, evidence = [], []

    def vote(name, value, weight=1):
        votes.append((value, weight))
        evidence.append(f"{name}: {'bullish' if value > 0 else 'bearish' if value < 0 else 'neutral/mixed'}")

    if pd.notna(last.ema200):
        if last.ema20 > last.ema50 > last.ema200: vote("EMA20/50/200 alignment", 1, 2)
        elif last.ema20 < last.ema50 < last.ema200: vote("EMA20/50/200 alignment", -1, 2)
        else: vote("EMA alignment", 0, 2)
    else:
        vote("EMA20 vs EMA50", 1 if last.ema20 > last.ema50 else -1 if last.ema20 < last.ema50 else 0, 2)

    vote("Close vs EMA20", 1 if last.close > last.ema20 else -1 if last.close < last.ema20 else 0)
    rsi = last.rsi14
    vote("RSI14", 1 if pd.notna(rsi) and 52 <= rsi <= 68 else
         -1 if pd.notna(rsi) and 32 <= rsi <= 48 else 0)
    vote("MACD histogram", 1 if last.macd_histogram > 0 else -1 if last.macd_histogram < 0 else 0)
    if pd.notna(last.bb_mid):
        vote("Bollinger middle band", 1 if last.close > last.bb_mid else -1 if last.close < last.bb_mid else 0)

    weighted = sum(v*w for v,w in votes) / sum(w for _,w in votes)
    score = int(round(max(0, min(100, 50 + 50*weighted))))
    tilt = "BULLISH" if score >= 60 else "BEARISH" if score <= 40 else "NEUTRAL"

    recent = x.tail(30)
    structure = market_structure(x)
    trend_regime, volatility_regime = describe_regime(last, x)
    return {
        "filename": filename,
        "timeframe": timeframe,
        "tilt": tilt,
        "bullish_score": score,
        "last_close": round(float(last.close), 6),
        "ema20": round(float(last.ema20), 6),
        "ema50": round(float(last.ema50), 6),
        "ema200": round(float(last.ema200), 6) if pd.notna(last.ema200) else "needs 200+ candles",
        "rsi14": round(float(rsi), 2) if pd.notna(rsi) else "not available",
        "macd_histogram": round(float(last.macd_histogram), 8),
        "atr14": round(float(last.atr14), 8) if pd.notna(last.atr14) else "not available",
        "patterns": "; ".join(find_patterns(x)),
        "structure": "Close above EMA20" if last.close > last.ema20 else "Close below EMA20",
        "market_structure": structure,
        "trend_regime": trend_regime,
        "volatility_regime": volatility_regime,
        "adx14": round(float(last.adx14), 2) if pd.notna(last.adx14) else "not available",
        "atr_percent": round(float(last.atr_pct), 4) if pd.notna(last.atr_pct) else "not available",
        "bollinger_width_percent": round(float(last.bb_width_pct), 4) if pd.notna(last.bb_width_pct) else "not available",
        "support_zone_low": round(float(recent.low.min()), 6),
        "resistance_zone_high": round(float(recent.high.max()), 6),
        "evidence": "; ".join(evidence)
    }

def follow_through_study(df: pd.DataFrame, horizon: int = 5) -> dict:
    """Descriptive study only; it does not simulate orders or money returns."""
    x = add_indicators(df)
    ema = np.where(x.ema20 > x.ema50, 1, np.where(x.ema20 < x.ema50, -1, 0))
    rsi = np.where(x.rsi14 >= 55, 1, np.where(x.rsi14 <= 45, -1, 0))
    macd = np.where(x.macd_histogram > 0, 1, np.where(x.macd_histogram < 0, -1, 0))
    direction = ema + rsi + macd
    future = x.close.shift(-horizon) - x.close
    valid = (np.abs(direction) >= 2) & future.notna() & (future != 0)
    count = int(valid.sum())
    if count == 0:
        return {"observations": 0, "hit_rate": "not enough observations",
                "method": f"Indicator direction compared with close movement {horizon} candles later."}
    correct = ((direction[valid] > 0) & (future[valid] > 0)) | ((direction[valid] < 0) & (future[valid] < 0))
    rate = 100 * float(correct.mean())
    return {
        "observations": count,
        "hit_rate": f"{rate:.1f}%",
        "method": f"Compared EMA20/50 + RSI14 + MACD direction with close movement {horizon} candles later. No orders, costs, leverage or returns simulated."
    }
