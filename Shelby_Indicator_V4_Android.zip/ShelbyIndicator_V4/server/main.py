from typing import List
import base64, json, os
try:
    from openai import OpenAI
except ImportError:
    OpenAI = None
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from indicators import load_ohlc, analyse_frame, follow_through_study

app = FastAPI(title="Shelby Indicator V4")
vision_client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY")) if OpenAI and os.environ.get("OPENAI_API_KEY") else None

@app.get("/health")
def health():
    return {"ok": True, "service": "Shelby Indicator V4", "version": "4.0"}

@app.post("/analyze-csv")
async def analyze_csv(
    files: List[UploadFile] = File(...),
    timeframes: str = Form(...),
    pair_label: str = Form("Not supplied")
):
    if not 2 <= len(files) <= 6:
        raise HTTPException(400, "Upload between 2 and 6 CSV files.")

    labels = {}
    for part in timeframes.split(","):
        if "=" in part:
            key, value = part.strip().split("=", 1)
            try:
                labels[int(key.strip())] = value.strip()
            except ValueError:
                continue

    frames, studies = [], []
    for index, upload in enumerate(files, start=1):
        raw = await upload.read()
        if len(raw) > 15 * 1024 * 1024:
            raise HTTPException(413, f"{upload.filename} exceeds 15 MB.")
        try:
            df = load_ohlc(raw)
            label = labels.get(index, f"File {index} (timeframe not labelled)")
            frames.append(analyse_frame(df, label, upload.filename or f"file_{index}.csv"))
            studies.append(follow_through_study(df))
        except ValueError as exc:
            raise HTTPException(400, f"{upload.filename}: {exc}")

    weights = []
    for item in frames:
        tf = item["timeframe"].upper()
        weights.append(1.5 if tf in {"D1", "W1", "MN1", "H4"} else
                       1.25 if tf in {"H1", "H2"} else 1.0)
    combined = sum(x["bullish_score"]*w for x,w in zip(frames,weights))/sum(weights)
    combined = int(round(combined))
    tilt = "BULLISH" if combined >= 80 else "BEARISH" if combined <= 20 else "NEUTRAL"

    weighted_rates = []
    for item in studies:
        rate = item["hit_rate"]
        if isinstance(rate, str) and rate.endswith("%"):
            weighted_rates.append((float(rate[:-1]), item["observations"]))
    if weighted_rates:
        hit = sum(r*n for r,n in weighted_rates)/sum(n for _,n in weighted_rates)
        hit_rate = f"{hit:.1f}% (weighted across uploaded files)"
    else:
        hit_rate = "not enough directional observations"

    counts = {"BULLISH": 0, "BEARISH": 0, "NEUTRAL": 0}
    for frame in frames:
        counts[frame["tilt"]] += 1
    disagreements = [
        f'{frame["timeframe"]}: {frame["tilt"]} ({frame["bullish_score"]}/100)'
        for frame in frames if frame["tilt"] != tilt
    ]

    return {
        "version": "4.0",
        "pair_label": pair_label,
        "timeframe_consensus": {
            "bullish": counts["BULLISH"],
            "bearish": counts["BEARISH"],
            "neutral": counts["NEUTRAL"],
            "total": len(frames),
            "agreement_percent": round(100 * max(counts.values()) / len(frames), 1),
            "mixed_timeframes": disagreements
        },
        "combined_bullish_score": combined,
        "combined_tilt": tilt,
        "overview": f"Numerically analysed {len(frames)} OHLC datasets. This is an evidence-agreement score, not a probability.",
        "timeframes": frames,
        "historical_validation": {
            "observations": sum(x["observations"] for x in studies),
            "hit_rate": hit_rate,
            "method": " ".join(x["method"] for x in studies)
        },
        "limitations": (
            "The historical follow-through figure is descriptive, not a trading-system backtest. "
            "It excludes spreads, slippage, commissions, swaps and market impact. "
            "CSV pair/timeframe labels are user supplied and not independently verified. "
            "Swing points require later candles for confirmation and can appear with delay. "
            "This educational app does not give instructions to trade."
        )
    }


IMAGE_PROMPT = """
You are Shelby Indicator's educational chart-image reviewer.
Describe only what is visibly supported by the screenshots. Do not invent
indicator values, prices, symbols, or timeframe labels. Identify visible
candlestick formations, visible indicators, broad trend structure, and possible
support/resistance zones. Say when something is unreadable or absent.
Return JSON with directional_tilt (BULLISH, BEARISH, or NEUTRAL), overview,
timeframe_findings, uncertainties. This is descriptive education only.
Never tell the user to buy, sell, enter, or exit a trade.
"""

@app.post("/analyze-images")
async def analyze_images(
    files: List[UploadFile] = File(...),
    timeframes: str = Form(...),
    pair_label: str = Form("Not supplied")
):
    if not 2 <= len(files) <= 6:
        raise HTTPException(400, "Upload between 2 and 6 images.")
    if vision_client is None:
        raise HTTPException(503, "Screenshot review requires OPENAI_API_KEY on the backend.")
    content = [{
        "type": "text",
        "text": f"User pair label: {pair_label}. Timeframe mapping in upload order: {timeframes}. These labels are not verified."
    }]
    for upload in files:
        raw = await upload.read()
        if len(raw) > 8 * 1024 * 1024:
            raise HTTPException(413, f"{upload.filename} exceeds 8 MB.")
        mime = upload.content_type or "image/jpeg"
        if not mime.startswith("image/"):
            raise HTTPException(400, "Only image files are accepted.")
        content.append({
            "type": "image_url",
            "image_url": {
                "url": f"data:{mime};base64,{base64.b64encode(raw).decode('ascii')}",
                "detail": "high"
            }
        })
    try:
        response = vision_client.chat.completions.create(
            model=os.environ.get("SHELBY_MODEL", "gpt-4o-mini"),
            messages=[
                {"role": "system", "content": IMAGE_PROMPT},
                {"role": "user", "content": content}
            ],
            response_format={"type": "json_object"},
            temperature=0.1
        )
        result = json.loads(response.choices[0].message.content)
        if result.get("directional_tilt") not in {"BULLISH", "BEARISH", "NEUTRAL"}:
            result["directional_tilt"] = "NEUTRAL"
        return result
    except Exception as exc:
        raise HTTPException(502, f"Screenshot review failed: {exc}")
