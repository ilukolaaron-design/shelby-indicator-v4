"""Generate synthetic candles for software testing only; not real market data."""
import csv, math, random
from datetime import datetime, timedelta, timezone

random.seed(23)
price = 1.0800
stamp = datetime(2025, 1, 1, tzinfo=timezone.utc)
with open("sample_eurusd_h1.csv", "w", newline="", encoding="utf-8") as f:
    w = csv.writer(f)
    w.writerow(["timestamp", "open", "high", "low", "close", "volume"])
    for i in range(420):
        drift = 0.00001 * math.sin(i / 19)
        change = drift + random.gauss(0, 0.00035)
        o, c = price, price + change
        h = max(o, c) + abs(random.gauss(0, 0.00015))
        l = min(o, c) - abs(random.gauss(0, 0.00015))
        w.writerow([stamp.isoformat(), f"{o:.6f}", f"{h:.6f}", f"{l:.6f}", f"{c:.6f}", random.randint(40, 250)])
        price, stamp = c, stamp + timedelta(hours=1)
print("Created synthetic sample_eurusd_h1.csv")
